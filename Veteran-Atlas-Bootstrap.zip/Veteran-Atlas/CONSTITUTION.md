# Constitution

See founding principles.
